# 実例構造を使って設計する

Read `.cursor/skills/cadmcp-cursor/SKILL.md` and follow it for the user's request.
Retain the exact original requirements; first inspect registered hardware and
Req2CAD availability. Retrieve and inspect real reference CAD before synthesis.
Build a typed prototype recipe, inspect real measurements and perform first-round
plus peer-challenge review using available read-only Cursor subagents. The parent
submits actual returned reviews. No invented model executions or fallback corpus.
Do not run Codex or Cursor CLI from this command. Keep canonical CAD untouched.
