# MCPツール一覧

生成元: `cadmcp_brain.api.Tools.list()`。正確な引数は`schemas/mcp-tools.json`またはbrain_schema/brain_task。

| 名前 | 用途 |
|---|---|
| `brain_add_source` | Append an exact new user instruction; invalidate old intent, concepts, plans and verification, preserving audit history. |
| `brain_backend_call` | Opt-in gated AgentCAD call. Owner allowlist required. Default dry-run. A call_id permits at most one network write attempt; never retry uncertain outcomes. |
| `brain_backend_probe` | Read the configured loopback AgentCAD live tool registry. Disabled unless CADMCP_AGENTCAD_URL is set by the owner. |
| `brain_doctor` | Report local capabilities without pretending to test a remote CAD backend or a Windows/Cursor installation. |
| `brain_export` | Export immutable contract.json, CAD_HANDOFF.md and design_graph.json for the existing CAD backend. Does not execute CAD. |
| `brain_get` | Read current state and revision. Reload after REVISION_CONFLICT; never overwrite a newer design. |
| `brain_history` | Read the transactional project event history. |
| `brain_import_step` | Copy/hash a workspace-relative STEP. output needs current contract digest; reference performs actual kernel measurements and invalidates concepts/plans. Trusted local STEP only. |
| `brain_open` | Start source-grounded design. request is the user's exact original text, not an invented paraphrase. Next call brain_task. |
| `brain_patterns` | Retrieve original mechanism patterns using lexical English/Japanese search. Results are not validated designs or dimensional allowables. |
| `brain_schema` | Read a versioned Brief, Concept, Concepts or Plan JSON schema. |
| `brain_select` | Select a gate-eligible concept. This does not attest human approval, printability, strength or fatigue life. |
| `brain_submit_concepts` | Commit 2–4 distinct FBS mechanism alternatives and return mechanical/declaration gate results for each. |
| `brain_submit_intent` | Validate and commit the source-linked Brief. Reject source omissions, fabricated quotations, contradictory constraints and mandatory inferences. |
| `brain_submit_plan` | Commit a typed geometric construction plan with dependency, provenance and test-obligation validation. |
| `brain_task` | Get the next host-model task, relevant state and exact JSON schema. The server does not pretend to understand natural language itself. |
| `brain_verify` | Measure imported B-reps and evaluate listed geometry checks. Missing/stale/unsupported evidence remains unknown; physical performance is not certified. |
