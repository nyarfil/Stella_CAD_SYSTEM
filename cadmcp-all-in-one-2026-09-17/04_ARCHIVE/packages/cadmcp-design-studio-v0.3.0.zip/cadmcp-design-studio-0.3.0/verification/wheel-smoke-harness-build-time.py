import os,sys,json,pathlib,subprocess,hashlib,time,zipfile
from importlib import metadata
INSTALL=pathlib.Path('/mnt/data/v03-wheel-installed')
ROOT=pathlib.Path('/mnt/data/cadmcp-design-studio-0.3.0')
WORK=pathlib.Path('/mnt/data/v03-wheel-smoke-workspace-'+str(time.time_ns()))
DEMO=json.loads(pathlib.Path('/mnt/data/v03-final-demo/DEMO_RESULT.json').read_text())
recipe=json.loads(pathlib.Path(DEMO['build']['recipe_path']).read_text())
import cadmcp_brain
assert pathlib.Path(cadmcp_brain.__file__).is_relative_to(INSTALL),cadmcp_brain.__file__
whl=ROOT/'dist/cadmcp_design_brain-0.3.0-py3-none-any.whl'
with zipfile.ZipFile(whl) as z:
    names=[n for n in z.namelist() if n.startswith('cadmcp_brain/') and not n.endswith('/')]
    assert all(z.read(n)==(ROOT/n).read_bytes() for n in names)
    wheel_files=len(names)
env=dict(os.environ,PYTHONPATH=str(INSTALL),CADMCP_REQ2CAD_ROOT='/mnt/data/v03-final-demo/knowledge/req2cad',PYTHONUTF8='1')
log=(ROOT/'verification/wheel-mcp-stderr.log').open('w')
p=subprocess.Popen([sys.executable,'-m','cadmcp_brain','--workspace',str(WORK),'serve'],cwd='/mnt/data',env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,text=True,encoding='utf-8',bufsize=1)
rid=0;receipts=[]
def send(method,params=None,notification=False):
    global rid
    rid+=1;m={'jsonrpc':'2.0','method':method,'params':params or {}}
    if not notification:m['id']=rid
    p.stdin.write(json.dumps(m,ensure_ascii=False)+'\n');p.stdin.flush()
    if notification:return
    line=p.stdout.readline()
    if not line:raise RuntimeError('MCP stdout ended before a response')
    r=json.loads(line);assert r['id']==rid and 'error' not in r,r
    return r['result']
def call(name,args,expect_error=False):
    started=time.time();r=send('tools/call',{'name':name,'arguments':args})
    assert bool(r['isError'])==expect_error,r
    v=r['structuredContent'];receipts.append({'tool':name,'expected_error':expect_error,'elapsed_seconds':round(time.time()-started,3),'ok':v['ok']})
    return v.get('result',v.get('error'))
try:
    init=send('initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'wheel-install-smoke','version':'1'}})
    send('notifications/initialized',notification=True)
    tools=send('tools/list')['tools'];assert len(tools)==33
    status=call('brain_fs_status',{})
    call('brain_studio_schema',{'name':'Recipe'})
    call('brain_open',{'project_id':'wheel-real-build','request':recipe['original_request']})
    call('brain_fs_interfaces',{'uid':'0032/00329619','required_features':['has_cylindrical_cavity_surface']})
    not_semantic=call('brain_fs_search',{'functions':['support rotation'],'mode':'semantic'},expect_error=True)
    search=call('brain_fs_search',{'functions':['support rotation'],'mode':'lexical'})
    built=call('brain_studio_build',{'project_id':'wheel-real-build','expected_revision':0,'recipe':recipe,'timeout_seconds':180})
    assert built['geometry_checks_verdict']=='pass' and built['overall_verdict']=='unknown'
    for role in ['requirements','mechanism','assembly','manufacturing','verification']:
        packet=call('brain_studio_review_packet',{'project_id':'wheel-real-build','expected_revision':0,'subject_digest':built['subject_digest'],'role':role})
        assert packet['role']==role
    review=call('brain_studio_review_status',{'project_id':'wheel-real-build','expected_revision':0,'subject_digest':built['subject_digest']})
    motion=next(c for c in built['checks'] if c['kind']=='sampled_translation_clearance')
    result={'ok':True,'test_kind':'installed-wheel actual MCP stdio + real reference CAD build; no model reasoning test','imported_package':cadmcp_brain.__file__,'source_directory_on_pythonpath':False,'version':cadmcp_brain.__version__,'wheel_sha256':hashlib.sha256(whl.read_bytes()).hexdigest(),'wheel_files_matching_source':wheel_files,'tool_count':len(tools),'protocol_version':init['protocolVersion'],'using_existing_dependency_environment':True,'clean_windows_install':False,'full_corpus_tested':False,'actual_model_called':False,'missing_semantic_index_correctly_rejected':True,'geometry_checks_verdict':built['geometry_checks_verdict'],'overall_verdict':built['overall_verdict'],'motion_samples':motion['final_samples'],'conditional_distance_lower_bound_mm':motion['continuous_distance_lower_bound_mm'],'assembly_step':built['assembly_step'],'receipts':receipts,'review_status':review}
    (ROOT/'verification/wheel-smoke.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['receipts','review_status']},ensure_ascii=False,indent=2))
finally:
    p.stdin.close()
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:p.kill();p.wait()
    log.close()
