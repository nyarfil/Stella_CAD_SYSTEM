# cadMCP Design Studio 0.3.0

Function–structure retrieval, measured CAD interfaces, reference-derived part generation,
bounded five-role review orchestration, and explicit verification evidence.

**[日本語の導入・実装説明](README_JA.md)** · [検証記録](TEST_REPORT_JA.md) · [設計手順](AGENT_WORKFLOW_JA.md)

This is an implemented, tested **bounded prototype-design system**, not a reproduction
of every Req2CAD feature or a certified general mechanical designer. Four selected
public-mirror CAD records are included with verified source hashes. The full corpus,
Qwen weights, actual Codex-provider reasoning, Windows, the owner's existing CAD
backend, and physical printing were not validated here. Scripted-provider tests are
explicitly separate from live-model evaluation.

A model proposes typed design data; deterministic CAD code measures it. Prototype
outputs never automatically replace canonical CAD or send work to a printer.
