# 0.3.0 — Function → real structure → adapted prototype

- Four source-hash-checked public CAD records, actual B-rep replay and reproducible demo.
- Geometric loop containment instead of trusting inconsistent is_outer metadata.
- Safe nested/compressed DeepCAD archive normalization.
- Grouped function retrieval; paraphrases do not create extra coverage votes.
- Measured inner/outer cylindrical and planar interfaces; evidence-bound face IDs.
- Typed morphological matrix and bounded compatible functional covers.
- Typed source-bound CAD adaptation; protected hardware and editing authority.
- Automatic output-pair interference, dimensions, clearances and bounded linear-motion checks.
- Native portable z-buffer PNG views + SVG/STEP, read-only local evidence report.
- Five-role review and peer-challenge orchestration; frozen-check repair.
- Optional bounded owner-authenticated Codex CLI provider; no implicit new API calls.
- 260 passing tests in the final Linux source run; live-model/full-corpus/Windows/physical tests remain outstanding.

0.2-era test totals and intermediate failed runs are not used as this release's results.
