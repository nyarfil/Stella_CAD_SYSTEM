# Implementation provenance

This package is an original implementation informed by the public approaches in
`docs/UPSTREAM_AUDIT_JA.md`. It does not vendor upstream agent prompts, source
modules, reference CAD files or a research dataset. References describe ideas,
not a claim that those entire products are embedded or integrated.

Dependencies are installed separately and retain their own licenses and notices:
Pydantic, jsonschema, optional CadQuery and their transitive dependencies;
pytest/coverage for testing. This project's MIT notice does not relicense them.
Upstream project license suitability has not been used as a basis to redistribute
any upstream source. Linking an upstream URL is not an endorsement or certification.

The 13 mechanism patterns and test solids are newly authored educational/design
starting points. They are not manufacturer-qualified mechanisms, fatigue limits,
printer calibration data or the Req2CAD knowledge base. No part is presented as a
copy of an actual commercial mouse.
