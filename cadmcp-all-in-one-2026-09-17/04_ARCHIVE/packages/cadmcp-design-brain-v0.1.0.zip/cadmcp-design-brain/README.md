# cadmcp-design-brain

A source-grounded design-decision MCP sidecar for an existing CAD executor.
Host LLM reasoning + typed intent/structure/plan contracts + deterministic gates +
optional measured STEP checks. No external LLM API is called by this package.

**Start with [README_JA.md](README_JA.md).**
Installation and integration: [INSTALL_INTEGRATE_JA.md](INSTALL_INTEGRATE_JA.md).
Evidence and limits: [TEST_REPORT_JA.md](TEST_REPORT_JA.md).
Upstream audit: [docs/UPSTREAM_AUDIT_JA.md](docs/UPSTREAM_AUDIT_JA.md).

This is a scoped, executable v0.1.0 implementation, not a certified autonomous
mechanical designer or a patch already applied to the user's existing repository.
The synthetic demo is not a functional mouse mechanism or an LLM benchmark.
