# Function → behavior → mechanism → components
Generate 2–4 genuinely different alternatives; do not spawn extra agents merely
because a pipeline exists. A single host can execute these roles sequentially.

For each concept:
- Functions use a verb and object. State expected observable behavior separately.
- Retrieve relevant mechanism patterns with brain_patterns. Catalog entries are
  authored starting points, not validated mouse designs or authoritative dimensions.
- Show how each function is realized, what physically carries its load, how moving
  parts are constrained, how parts return, what limits travel and how they assemble.
- Include printed, purchased and reference components, their material, manufacturing
  orientation and assembly/tool access. Do not silently omit the PCB or switch support.
- Interfaces must connect distinct existing components. Avoid floating parts and
  overconstraint. A connectivity graph alone does not prove assembly feasibility.
- For side buttons, inspect the ACTUAL switch actuation direction. A switch beside
  the button, actuated along the same axis, normally warrants evaluating direct
  actuation before introducing a motion-redirection mechanism. Do not invent a
  vertically facing switch. Left/right refers to the explicitly declared frame.
- Direct mechanisms must have matching input/output unit vectors. For a lever,
  explain the pivot, force ratio, output contact trajectory and resulting side loads.
- Specify return and hard stop. The internal switch spring may not overcome guide
  friction, gravity or tolerance stack-up. Printed flexure fatigue is not established
  by a plausible shape, a static FEA pass or a generic ABS material value.
- Prefer separately printable parts where critical guide/contact surfaces would
  otherwise sit on supports. Do not prescribe universal clearances or wall thickness.
- List realistic failure modes, blocking unknowns and alternatives rejected on grounds.

Compare conventional/simple versus flexure or lever solutions as applicable.
A rejected alternative may remain in the comparison. The server will forbid selecting
one with violated hard gates. Do not fabricate numerical "quality" or confidence.
Submit the Concepts envelope via brain_submit_concepts, then inspect evaluations.
