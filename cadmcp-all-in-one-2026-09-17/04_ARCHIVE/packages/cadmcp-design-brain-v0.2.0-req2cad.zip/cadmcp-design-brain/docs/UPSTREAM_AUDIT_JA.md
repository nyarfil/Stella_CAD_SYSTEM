# 上流調査・採用対応 — v0.2.0

本版の中心はReq2CADのFunction–Structure KBです。詳細・原版との差・一次資料は
`../../` ではなく、リポジトリ直下の `REQ2CAD_IMPLEMENTATION_JA.md` を参照してください。

| 元プロジェクト | 本版での扱い |
|---|---|
| Req2CAD | 機能注釈の全件取込経路、機能語埋め込み、実UID→CAD、実B-rep面隣接/WL、構造参照の設計利用を独立実装 |
| DeepCAD | 公式JSONの曲線/押出/boolean仕様を読み、native replayを独立実装。元コードを依存として実行せず、未知操作は拒否 |
| Qwen3-Embedding-4B | ローカルSentenceTransformerアダプター。重みの実取得/推論は本環境で未確認 |
| agent-spec / Agentic Engineering Design / MAC / AgentCAD | v0.1で参考にした要求IR・設計状態・契約分離・APIブリッジを維持 |
| iDesignGPT / AI-CAD / CADDesigner | 本版でそれらの全パイプラインを移植したわけではない |

古い監査内容は `docs/archive/v0.1.0/UPSTREAM_AUDIT_JA.md` に保存しています。
その「Req2CADを取り込んでいない」はv0.1の説明であり、v0.2のコードに関する説明ではありません。
一方、v0.2でも**フルデータ/重みをこの環境で導入できた**とはしていません。
