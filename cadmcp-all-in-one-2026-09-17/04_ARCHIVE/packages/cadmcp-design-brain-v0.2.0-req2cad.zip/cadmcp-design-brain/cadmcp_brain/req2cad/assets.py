"""Explicit owner-side asset registration. Uncompressed TAR is indexed, not extracted.

CAD locations are joined by exact uid, never by fuzzy matching or file order.
"""
from __future__ import annotations
import hashlib, json, os, re, shutil, tarfile, uuid
from pathlib import Path,PurePosixPath
from .common import *

MAX_JSON=16*1024**2
MAX_STEP=256*1024**2

def file_uid(name):
    p=PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or '\\' in name or ':' in name: return None
    if len(p.parts)<2: return None
    candidate=p.parts[-2]+'/'+p.stem
    return candidate if re.fullmatch(r'\d{4}/\d{8}',candidate) else None


def attach_directory(catalog,root,kind,scale_to_mm,unit_basis,source_url,license_note,reference_only=False):
    """Owner CLI only. No arbitrary path registration is exposed to the LLM."""
    root=Path(root).expanduser().resolve();scale_to_mm=finite(scale_to_mm,positive=True)
    if kind not in ('deepcad_json','step') or not root.is_dir() or not unit_basis.strip(): raise BrainError('FS_ASSET','Specify directory, kind, explicit scale and unit evidence.')
    suffixes={'.json'} if kind=='deepcad_json' else {'.step','.stp'}
    linked=0;unmatched=0;seen=set()
    with write_lock(catalog.root),catalog.connect() as db:
        for p in sorted(root.rglob('*')):
            if not p.is_file() or p.suffix.lower() not in suffixes: continue
            if any(a.is_symlink() for a in [p,*p.parents] if a!=root.parent):
                raise BrainError('FS_ASSET','Symbolic links in source assets are not accepted.')
            key=file_uid(p.relative_to(root).as_posix())
            if key is None: continue
            if key in seen: raise BrainError('FS_ASSET_DUPLICATE','Multiple files map to one UID; no registry changes committed.',{'uid':key})
            seen.add(key)
            if not db.execute('SELECT 1 FROM cases WHERE uid=?',(key,)).fetchone(): unmatched+=1;continue
            trusted_file(p,MAX_JSON if kind=='deepcad_json' else MAX_STEP)
            st=p.stat();sha=file_hash(p)
            if (p.stat().st_size,p.stat().st_mtime_ns)!=(st.st_size,st.st_mtime_ns): raise BrainError('FS_CHANGED','Source changed while registering.')
            old=db.execute('SELECT * FROM assets WHERE uid=?',(key,)).fetchone()
            if old and (old['sha256']!=sha or old['scale_to_mm']!=scale_to_mm or bool(old['reference_only'])!=reference_only): db.execute('DELETE FROM geometry WHERE uid=?',(key,))
            db.execute('INSERT OR REPLACE INTO assets VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
              (key,kind,str(p),None,sha,st.st_size,st.st_mtime_ns,scale_to_mm,unit_basis,source_url,license_note,int(reference_only)));linked+=1
        db.commit()
    return {'linked':linked,'unmatched_files':unmatched,'kind':kind,'unit_basis':unit_basis}


def attach_tar(catalog,path,scale_to_mm,unit_basis,source_url,license_note,reference_only=False):
    """Read the official uncompressed data.tar; retain original JSONs in-place."""
    path=trusted_file(Path(path).resolve(),64*1024**3);scale_to_mm=finite(scale_to_mm,positive=True)
    if not unit_basis.strip(): raise BrainError('FS_UNITS','Explicit units evidence is required.')
    st=path.stat();archive_hash=file_hash(path);linked=0;unmatched=0;duplicates=set()
    with write_lock(catalog.root),catalog.connect() as db,tarfile.open(path,'r:') as tar:
        for member in tar:
            if not member.name.endswith('.json') or 'cad_json' not in PurePosixPath(member.name).parts: continue
            key=file_uid(member.name)
            if not key: raise BrainError('FS_ARCHIVE','Unsafe or malformed CAD member name.')
            if key in duplicates: raise BrainError('FS_ARCHIVE','Duplicate UID in archive.',{'uid':key})
            duplicates.add(key)
            if not member.isfile() or member.issym() or member.islnk() or member.size>MAX_JSON: raise BrainError('FS_ARCHIVE','Non-regular or oversized CAD member.')
            if not db.execute('SELECT 1 FROM cases WHERE uid=?',(key,)).fetchone(): unmatched+=1;continue
            f=tar.extractfile(member)
            if f is None: raise BrainError('FS_ARCHIVE','Could not read member.')
            data=f.read(MAX_JSON+1);sha=hashlib.sha256(data).hexdigest()
            old=db.execute('SELECT * FROM assets WHERE uid=?',(key,)).fetchone()
            if old and (old['sha256']!=sha or old['scale_to_mm']!=scale_to_mm or bool(old['reference_only'])!=reference_only): db.execute('DELETE FROM geometry WHERE uid=?',(key,))
            # Store exact seek position and archive file identity. No extractall/path traversal.
            locator=canonical({'name':member.name,'offset_data':member.offset_data,'size':member.size,'archive_sha256':archive_hash})
            db.execute('INSERT OR REPLACE INTO assets VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
               (key,'deepcad_tar',str(path),locator,sha,st.st_size,st.st_mtime_ns,scale_to_mm,unit_basis,source_url,license_note,int(reference_only)));linked+=1
        if path.stat().st_size!=st.st_size or path.stat().st_mtime_ns!=st.st_mtime_ns: raise BrainError('FS_CHANGED','Archive changed during registration.')
        db.commit()
    return {'linked':linked,'unmatched_files':unmatched,'archive_sha256':archive_hash,'units_basis':unit_basis}


def read_asset(asset):
    path=Path(asset['path']);st=path.stat()
    if path.is_symlink() or not path.is_file() or st.st_size!=asset['size'] or st.st_mtime_ns!=asset['mtime_ns']:
        raise BrainError('FS_ASSET_CHANGED','Re-register changed/missing source asset.')
    if asset['kind']=='deepcad_tar':
        loc=json.loads(asset['member']);size=loc['size']
        if size>MAX_JSON or loc['offset_data']<0: raise BrainError('FS_ARCHIVE','Invalid member bounds.')
        with path.open('rb') as f: f.seek(loc['offset_data']);data=f.read(size)
    else:
        trusted_file(path,MAX_STEP if asset['kind']=='step' else MAX_JSON);data=path.read_bytes()
    if hashlib.sha256(data).hexdigest()!=asset['sha256']: raise BrainError('FS_ASSET_CHANGED','CAD content checksum mismatch.')
    return data


def download_file(url,destination,expected_sha256=None,max_bytes=2*1024**3):
    """CLI-only download; streams to a temporary file and checks content hash.

    No user-supplied URL is accepted by MCP tools. TLS verification is not disabled.
    """
    import urllib.request
    destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
    if destination.is_file() and expected_sha256 and file_hash(destination)==expected_sha256: return str(destination)
    tmp=destination.with_name(destination.name+'.'+uuid.uuid4().hex+'.partial')
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'cadmcp-req2cad/0.2.0'})
        with urllib.request.urlopen(req,timeout=60) as r,tmp.open('wb') as f:
            n=0;h=hashlib.sha256()
            while True:
                block=r.read(1024**2)
                if not block: break
                n+=len(block)
                if n>max_bytes: raise BrainError('FS_DOWNLOAD','Download exceeded configured size limit.')
                f.write(block);h.update(block)
        if not n: raise BrainError('FS_DOWNLOAD','Empty download.')
        if expected_sha256 and h.hexdigest()!=expected_sha256: raise BrainError('FS_HASH','Downloaded data differs from pinned source; no file installed.')
        os.replace(tmp,destination)
        return str(destination)
    finally: tmp.unlink(missing_ok=True)
