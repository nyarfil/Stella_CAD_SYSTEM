# cadMCP Design Brain 0.2.0 — Req2CAD extension

See **README_JA.md**, **INSTALL_INTEGRATE_JA.md**, and **REQ2CAD_IMPLEMENTATION_JA.md**.

Real-UID function/CAD catalog; keyword embeddings; DeepCAD JSON replay; STEP/STL/SVG;
B-rep face-adjacency/WL comparison; explicit CAD evidence in design contracts.

The original dataset, CAD corpus and pretrained weights are **not bundled or tested
at full scale here**. Owner-side scripts fetch them. The included geometry fixtures
are author-created, not original Req2CAD examples. This is not the original authors'
complete application or learned geometric encoder. Read TEST_REPORT_JA.md for scope.
